//
//  Cliente.hpp
//  TP4
//
//  Created by Tomas Nagy on 21/06/2019.
//  Copyright © 2019 Tomas Nagy. All rights reserved.
//

#ifndef Cliente_hpp
#define Cliente_hpp

#include <stdio.h>
#include <string>

using namespace std;

const float DESCUENTO_FAMILIA = 0.1;
const float DESCUENTO_INDIVIDUO = 0.35;

class Cliente{
    private:
        int nombre;
        int telefono;
    
    public:
        void agregarCliente(string nombre, int telefono);
        void eliminarCliente();
        void listarClientes();
        Cliente buscarPorNumero();
        ~Cliente();
};

#endif /* Cliente_hpp */
