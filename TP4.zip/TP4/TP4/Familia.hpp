//
//  Familia.hpp
//  TP4
//
//  Created by Tomas Nagy on 21/06/2019.
//  Copyright © 2019 Tomas Nagy. All rights reserved.
//

#ifndef Familia_hpp
#define Familia_hpp

#include <stdio.h>

#endif /* Familia_hpp */
