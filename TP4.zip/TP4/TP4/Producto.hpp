//
//  Producto.hpp
//  TP4
//
//  Created by Tomas Nagy on 21/06/2019.
//  Copyright © 2019 Tomas Nagy. All rights reserved.
//

#ifndef Producto_hpp
#define Producto_hpp


#include <stdio.h>
#include <string>

using namespace std;

class Producto{
private:
    int nombre;
    int producto;
    
public:
};

#endif /* Producto_hpp */
