//
//  main.cpp
//  TP4
//
//  Created by Tomas Nagy on 21/06/2019.
//  Copyright © 2019 Tomas Nagy. All rights reserved.
//

#include <iostream>
#include <list>



int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
    std::list <Cliente> clientes;

}
